package com.example.order.domain.model;

import java.util.List;

public record OrderSnapshot(
        String id, long version, String status, List<OrderLineSnapshot> lines) {}