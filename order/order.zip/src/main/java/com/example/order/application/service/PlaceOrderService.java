package com.example.order.application.service;

import com.example.order.application.port.in.PlaceOrderCommand;
import com.example.order.application.port.in.PlaceOrderUseCase;
import com.example.order.application.port.out.SaveOrderPort;
import com.example.order.domain.ids.OrderId;
import com.example.order.domain.model.Order;
import com.example.order.domain.model.OrderLine;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class PlaceOrderService implements PlaceOrderUseCase {
    private final SaveOrderPort saveOrder;
    // (다른 포트: PaymentGatewayPort, InventoryPort 등…)

    public PlaceOrderService(SaveOrderPort saveOrder /* ... */) {
        this.saveOrder = saveOrder;
    }

    @Override
    public OrderId place(PlaceOrderCommand cmd) {
        OrderId id = new OrderId(cmd.orderId());
        var lines = cmd.lines().stream()
                .map(l -> new OrderLine(l.productId(), l.qty(), l.unitPrice()))
                .toList();

        Order order = Order.place(id, lines);         // 도메인 규칙 실행
        saveOrder.save(order.toSnapshot());           // ★ 스냅샷만 외부로
        return id;
    }
}