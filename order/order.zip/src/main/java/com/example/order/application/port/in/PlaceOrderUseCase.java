package com.example.order.application.port.in;

import com.example.order.domain.ids.OrderId;

public interface PlaceOrderUseCase {
    OrderId place(PlaceOrderCommand cmd);
}
