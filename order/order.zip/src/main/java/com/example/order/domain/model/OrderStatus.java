package com.example.order.domain.model;

public enum OrderStatus { PLACED, CANCELLED, COMPLETED }
