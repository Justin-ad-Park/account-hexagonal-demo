package com.example.order.application.port.in;

import java.util.List;

public record PlaceOrderCommand(String orderId, List<OrderLineCommand> lines) {}