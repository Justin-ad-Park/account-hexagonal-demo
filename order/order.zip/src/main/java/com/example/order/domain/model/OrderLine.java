package com.example.order.domain.model;

public record OrderLine(String productId, int qty, long unitPrice) {
    OrderLineSnapshot toSnapshot() { return new OrderLineSnapshot(productId, qty, unitPrice); }
    static OrderLine fromSnapshot(OrderLineSnapshot s) { return new OrderLine(s.productId(), s.qty(), s.unitPrice()); }
}