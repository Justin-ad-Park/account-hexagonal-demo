package com.example.order.domain.model;

import com.example.order.domain.ids.OrderId;

import java.util.List;

public final class Order {
    private final OrderId id;
    private final List<OrderLine> lines;
    private OrderStatus status;
    private long version;

    private Order(OrderId id, List<OrderLine> lines, OrderStatus status, long version) {
        this.id = id; this.lines = List.copyOf(lines); this.status = status; this.version = version;
    }

    public static Order place(OrderId id, List<OrderLine> lines) {
        // 도메인 규칙 검증…
        return new Order(id, lines, OrderStatus.PLACED, 0L);
    }

    public void onPaymentAuthorized() { /* 상태전이 규칙 */ }
    public void onPaymentFailed()     { /* 상태전이 규칙 */ }

    // ★ 스냅샷(불변 데이터 구조)로 경계 건넙니다.
    public OrderSnapshot toSnapshot() {
        return new OrderSnapshot(id.value(), version, status.name(),
                lines.stream().map(OrderLine::toSnapshot).toList());
    }

    public static Order fromSnapshot(OrderSnapshot s) {
        return new Order(
                new OrderId(s.id()),
                s.lines().stream().map(OrderLine::fromSnapshot).toList(),
                OrderStatus.valueOf(s.status()),
                s.version()
        );
    }
}