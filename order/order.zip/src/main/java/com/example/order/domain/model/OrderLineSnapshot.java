package com.example.order.domain.model;

public record OrderLineSnapshot(String productId, int qty, long unitPrice) {}