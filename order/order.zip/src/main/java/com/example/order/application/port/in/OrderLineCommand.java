package com.example.order.application.port.in;

public record OrderLineCommand(String productId, int qty, long unitPrice) {}