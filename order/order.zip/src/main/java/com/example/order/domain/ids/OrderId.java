package com.example.order.domain.ids;

public record OrderId(String value) {}